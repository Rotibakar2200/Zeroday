-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Waktu pembuatan: 11 Nov 2024 pada 20.54
-- Versi server: 10.2.44-MariaDB-cll-lve
-- Versi PHP: 8.1.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `apiw3844_Anjai`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `comments`
--

CREATE TABLE `comments` (
  `id` int(11) NOT NULL,
  `author` varchar(255) NOT NULL,
  `text` text NOT NULL,
  `photo` varchar(255) DEFAULT NULL,
  `timestamp` datetime DEFAULT current_timestamp(),
  `likes` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `posts`
--

CREATE TABLE `posts` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `user` varchar(100) NOT NULL,
  `profileImage` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `video` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `posts`
--

INSERT INTO `posts` (`id`, `title`, `content`, `user`, `profileImage`, `image`, `created_at`, `video`) VALUES
(21, 'Andaikan datang kembali', 'Abcd', 'ADMIN', 'profilPhoto/profile_zlzopy09ig8_anonalien.gif', 'uploadPost/1731264262480-1731073712084-1731057904831-FB_IMG_1730352591655.jpg', '2024-11-10 18:44:23', NULL);

-- --------------------------------------------------------

--
-- Struktur dari tabel `replies`
--

CREATE TABLE `replies` (
  `id` int(11) NOT NULL,
  `comment_id` int(11) NOT NULL,
  `author` varchar(255) NOT NULL,
  `text` text NOT NULL,
  `timestamp` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `licensekey` varchar(50) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `iprdp` varchar(255) DEFAULT NULL,
  `userrdp` varchar(255) DEFAULT NULL,
  `passrdp` varchar(255) DEFAULT NULL,
  `expireddate` date DEFAULT NULL,
  `registrationdate` datetime DEFAULT current_timestamp(),
  `userkey` varchar(255) DEFAULT NULL,
  `version` varchar(50) DEFAULT NULL,
  `downloadlink` varchar(255) DEFAULT NULL,
  `photo` varchar(255) DEFAULT NULL,
  `last_login` datetime DEFAULT current_timestamp(),
  `status` enum('online','offline') DEFAULT 'offline',
  `last_active` datetime DEFAULT NULL,
  `banner` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `licensekey`, `phone`, `iprdp`, `userrdp`, `passrdp`, `expireddate`, `registrationdate`, `userkey`, `version`, `downloadlink`, `photo`, `last_login`, `status`, `last_active`, `banner`) VALUES
(33, 'apiw3844_Anjai', '123@gmail.com', '$2y$10$02mEcDpxjtX1rVsBeKCy8OhmO/L9Q.lxmLni/W1CnaM5k1eUUJsYG', '123', 'Not add', 'On Progress....', 'On Progress....', 'On Progress....', '0000-00-00', '2024-11-10 00:00:00', 'On Progress....', 'BX.SPY v1.0', 'https://example.com/download/ali', 'profilPhoto/profile_t1mv0u50iol_IMG_20241109_201044.jpg', '2024-11-11 01:24:20', 'offline', NULL, NULL),
(34, 'ADMIN', '1237@gmail.com', '$2y$10$khJbbpMV96HkH.gkuTkIzu2.VzarZc1yQUC/5pa54uLFJEOPTPAQO', '1234', 'Not add', 'On Progress....', 'On Progress....', 'On Progress....', '0000-00-00', '2024-11-10 00:00:00', 'On Progress....', 'BX.SPY v1.0', 'https://example.com/download/ali', 'profilPhoto/profile_zlzopy09ig8_anonalien.gif', '2024-11-11 01:30:51', 'offline', '2024-11-11 15:57:45', NULL),
(35, 'ADMIN2', 'genjitakiys@gmail.com', '$2y$10$Rm2L1MFA60s0Nn/UpPgqkeMIAYjUPwc1N1gN7FMkC1IQ6k7jrvQa2', '1234ww', 'Not add', 'On Progress....', 'On Progress....', 'On Progress....', '0000-00-00', '2024-11-10 00:00:00', 'On Progress....', 'BX.SPY v1.0', 'https://example.com/download/ali', 'profilPhoto/profile_zb43mr37wzq_anonalien.gif', '2024-11-11 01:39:38', 'offline', '2024-11-11 20:53:03', 'https://i.imgur.com/1mbMtgh.gif');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `replies`
--
ALTER TABLE `replies`
  ADD PRIMARY KEY (`id`),
  ADD KEY `comment_id` (`comment_id`);

--
-- Indeks untuk tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `licensekey` (`licensekey`),
  ADD UNIQUE KEY `licensekey_2` (`licensekey`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT untuk tabel `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT untuk tabel `replies`
--
ALTER TABLE `replies`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT untuk tabel `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `replies`
--
ALTER TABLE `replies`
  ADD CONSTRAINT `replies_ibfk_1` FOREIGN KEY (`comment_id`) REFERENCES `comments` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
