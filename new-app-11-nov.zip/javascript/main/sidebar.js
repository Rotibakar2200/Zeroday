const toggleSidebar = document.getElementById('toggleSidebar');
        const sidebar = document.getElementById('sidebar');
        
        //const overlay = document.getElementById('overlay');
        const menuLabel = document.querySelector('.menu-label span');
        const profileView = document.getElementById('profileView');
        const menuButtons = document.querySelectorAll('.menu-button');
        const closeSidebar = document.getElementById('closeSidebar');

        // Event listener untuk toggle sidebar
        toggleSidebar.addEventListener('click', (e) => {
            e.preventDefault();
            sidebar.classList.toggle('open');
            overlay.classList.toggle('active');
        });
        
        toggleRightSidebar.addEventListener('click', () => {
                rightSidebar.classList.toggle('open');
                overlay.classList.toggle('active');
        });
        
        // Event listener untuk menu profil
        profil_menu.addEventListener('click', () => {
            menuLabel.textContent = 'PROFIL';
            menuButtons.forEach(button => {
                button.classList.add('hidden');
            });


            // Tampilkan profil dan informasi tambahan
            profileView.classList.remove('hidden');
            additionalInfo.classList.remove('hidden');
            separator.classList.remove('hidden');
            separator.classList.add('slide-in');
            separator2.classList.remove('hidden');
            separator2.classList.add('slide-in');
            
            additionalInfo.classList.add('slide-in');
            profileView.classList.add('slide-in');
            mainView.classList.add('slide-out');
            
            // Hapus kelas slide-out setelah animasi selesai
            setTimeout(() => {
                mainView.classList.add('hidden');
                mainView.classList.remove('slide-out');
            }, 300);
        });
        
        // Event listener untuk menu utama
        main_menu.addEventListener('click', () => {
            menuLabel.textContent = 'MENU UTAMA';
            profileView.classList.add('hidden');
            menuButtons.forEach(button => {
                button.classList.remove('hidden');
            });
            mainView.classList.remove('hidden');
            mainView.classList.add('slide-in');
            profileView.classList.add('slide-out');
            
            additionalInfo.classList.add('hidden');
            separator.classList.add('hidden');
            separator2.classList.add('hidden');
            setTimeout(() => {
                profileView.classList.remove('slide-out');
            }, 300);
        });

        // Event listener untuk overlay
        overlay.addEventListener('click', () => {
            sidebar.classList.remove('open');
            rightSidebar.classList.remove('open');
            overlay.classList.remove('active');
        });

        // Event listener untuk menutup sidebar
        closeSidebar.addEventListener('click', () => {
            sidebar.classList.remove('open');
            overlay.classList.remove('active');
        });
        
        closeRightSidebar.addEventListener('click', () => {
                rightSidebar.classList.remove('open');
                overlay.classList.remove('active');
        });
        
        
        // Fungsi untuk toggle dropdown
        function toggleDropdown(dropdownId) {
            const dropdown = document.getElementById(dropdownId);
            dropdown.classList.toggle('active');
        }
        