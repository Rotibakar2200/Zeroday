// Menampilkan modal kesalahan dengan pesan yang diberikan
function showErrorModal(message) {
    const errorMessage = document.getElementById('errorMessage');
    errorMessage.textContent = message; // Set pesan kesalahan
    const errorModal = document.getElementById('errorModal');
    errorModal.classList.remove('hidden'); // Tampilkan modal
}

// Mengambil komentar dari API dan menampilkannya di halaman
function fetchComments() {
    const commentsSection = document.getElementById('commentsSection');
    const loadingIndicator = document.getElementById('loadingIndicator');

    loadingIndicator.classList.remove('hidden'); // Tampilkan indikator loading

    fetch('https://api-traives.my.id/api/get-comments.php', {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json',
        }
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.json();
    })
    .then(data => {
        if (!data.success) {
            throw new Error(data.message);
        }

        // Generate HTML untuk komentar
        const commentsHTML = data.comments.map(comment => {
            const date = new Date(comment.timestamp);
            const options = { year: 'numeric', month: 'long', Day: 'numeric', hour: '2-digit', minute: '2-digit', hour12: false };
            const formattedDate = date.toLocaleDateString('id-ID', options);

            // Generate HTML untuk balasan
            const repliesHTML = comment.replies.map(reply => {
                const replyDate = new Date(reply.timestamp);
                const formattedReplyDate = replyDate.toLocaleDateString('id-ID', options);
                return `
                <div class="reply mb-2 pl-4 shadow-lg p-2 rounded-md">
                    <div class="flex items-start">
                    <img src="https://api-traives.my.id/api/${comment.photo || 'image/default_photo.png'}" alt="User  Icon" class="user-icon w-8 h-8 rounded-full mr-2" />
                        <div class="reply-content flex-1">
                            <p class="username font-semibold text-gray-700">${reply.author}</p>
                            <p class="timestamp text-xs text-gray-500">${formattedReplyDate}</p>
                            <p class="message text-gray-600">${reply.text}</p>
                        </div>
                    </div>
                </div>`;
            }).join('');

            // Generate HTML untuk setiap komentar
            return `
            <div class="comment mb-4 p-4 shadow-lg rounded-md">
                <div class="flex items-start">
                    <img src="https://api-traives.my.id/api/${comment.photo || 'image/default_photo.png'}" alt="User  Icon" class="user-icon w-10 h-10 rounded-full mr-3" />
                    <div class="comment-content flex-1">
                        <p class="username font-semibold text-gray-700">${comment.author}</p>
                        <p class="timestamp text-xs text-gray-500">${formattedDate}</p>
                        <p class="message text-gray-600">${comment.text}</p>
                        <div class="comment-actions mt-2">
                            <button onclick="replyToComment(${comment.id})" class="text-[#FF9F00]">Balas</button>
                            <button onclick="likeComment(${comment.id})" class="text-[#FF9F00]">Sukai (<span id="like-count-${comment.id}">${comment.likes}</span>)</button>
                            <button onclick="toggleReplies(${comment.id})" class="text-[#FF9F00]">Lihat Balasan</button>
                        </div>
                        <div class="reply-input mt-2" id="reply-input-${comment.id}" style="display: none;">
                            <textarea placeholder="Tulis balasan..." rows="3" class="w-full p-2 border border-gray-300 rounded-md"></textarea>
                            <button onclick="submitReply(${comment.id})" class="bg-[#FF9F00] text-white px-4 py-2 rounded-md mt-1">Kirim</button>
                        </div>
                        <div class="replies hidden" id="replies-${comment.id}">${repliesHTML}</div>
                    </div>
                </div>
            </div>`;
        }).join('');

        // Update bagian komentar dengan HTML yang dihasilkan
        commentsSection.innerHTML = commentsHTML;
        commentsSection.classList.remove('hidden'); // Tampilkan bagian komentar
        loadingIndicator.classList.add('hidden'); // Sembunyikan indikator loading
    })
    .catch(error => {
        console.error('Error fetching comments:', error);
        showErrorModal('Gagal mengambil komentar. Silakan coba lagi.');
        loadingIndicator.classList.add('hidden'); // Sembunyikan indikator loading
    });
}

// Menampilkan atau menyembunyikan balasan untuk komentar tertentu
function toggleReplies(id) {
    const repliesDiv = document.getElementById(`replies-${id}`);
    repliesDiv.style.display = repliesDiv.style.display === "none" ? "block" : "none"; // Toggle visibility
}

// Menampilkan input balasan untuk komentar tertentu
function replyToComment(id) {
    const replyInputDiv = document.getElementById(`reply-input-${id}`);
    replyInputDiv.style.display = replyInputDiv.style.display === "none" ? "block" : "none"; // Toggle visibility
}

// Menyukai komentar tertentu
function likeComment(id) {
    fetch('https://api-traives.my.id/api/save-comments.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            like: true,
            comment_id: id, // Menggunakan ID komentar untuk menyukai
            password: 'DEBIAN123' // Ganti dengan password yang sesuai
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Update jumlah suka di UI
            const likeCountElement = document.getElementById(`like-count-${id}`);
            let currentCount = parseInt(likeCountElement.textContent);
            likeCountElement.textContent = currentCount + 1; // Increment jumlah suka
        } else {
            console.error('Failed to like the comment:', data.message);
        }
    })
    .catch(error => {
        console.error('Error:', error);
    });
}

// Mengirim balasan untuk komentar tertentu
function submitReply(id) {
    const replyInputDiv = document.getElementById(`reply-input-${id}`);
    const textarea = replyInputDiv.querySelector('textarea');
    const replyText = textarea.value;
    const username = localStorage.getItem('username') || 'Anonymous';

    if (replyText) {
        fetch('https://api-traives.my.id/api/save-comments.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                username: username,
                comment: replyText,
                replyTo: id, // Menyertakan ID komentar yang dibalas
                password: 'DEBIAN123' // Ganti dengan password yang sesuai
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Balasan berhasil dikirim!');
                textarea.value = ''; // Kosongkan input setelah berhasil
                fetchComments(); // Ambil komentar terbaru
            } else {
                showErrorModal('Gagal mengirim balasan: ' + data.message);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            showErrorModal('Terjadi kesalahan saat mengirim balasan.');
        });
    } else {
        alert('Silakan masukkan balasan sebelum mengirim.');
    }
}

// Event listener untuk tombol "Show Comments"
document.getElementById('showCommentsBtn').addEventListener('click', function() {
    const commentsSection = document.getElementById('commentsSection');
    if (commentsSection.classList.contains('hidden')) {
        fetchComments();
    } else {
        commentsSection.classList.add('hidden');
    }
});

// Event listener untuk tombol "Kirim"
document.getElementById('sendCommentBtn').addEventListener('click', function() {
    const commentInput = document.getElementById('commentInput');
    const commentText = commentInput.value;
    const username = localStorage.getItem('username') || 'Anonymous';
    const userPhoto = localStorage.getItem('profil') || 'Anonymous';
    const timestamp = new Date().toISOString(); // Menyimpan timestamp saat komentar dikirim

    if (commentText.trim() === '') {
        showErrorModal('Komentar tidak boleh kosong!');
        return;
    }

    fetch('https://api-traives.my.id/api/save-comments.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            username: username,
            comment: commentText,
            userPhoto: userPhoto, // Sertakan foto profil
            timestamp: timestamp, // Menyertakan timestamp
            password: 'DEBIAN123' // Ganti dengan password yang sesuai
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert('Komentar berhasil dikirim!');
            commentInput.value = ''; // Kosongkan input setelah berhasil
            fetchComments(); // Ambil komentar terbaru
        } else {
            showErrorModal('Gagal mengirim komentar.');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        showErrorModal('Terjadi kesalahan saat mengirim komentar.');
    });
});

// Event listener untuk menutup modal
document.getElementById('closeModalBtn').addEventListener('click', function() {
    const errorModal = document.getElementById('errorModal');
    errorModal.classList.add('hidden');
});