// Mendapatkan elemen DOM yang diperlukan
const accountToggle = document.getElementById('accountToggle');
const dropdownMenu = document.getElementById('dropdownMenu');
const notificationDropdown = document.getElementById('notificationDropdown');
const overlay = document.getElementById('overlay');
const notificationIcon = document.getElementById('notificationIcon');

// Menampilkan atau menyembunyikan dropdown notifikasi saat ikon notifikasi diklik
notificationIcon.addEventListener('click', (event) => {
    event.stopPropagation();
    notificationDropdown.classList.toggle('hidden');
    overlay.classList.toggle('hidden');
    overlay.classList.toggle('active');
});

// Menampilkan atau menyembunyikan menu akun saat diklik
accountToggle.addEventListener('click', (event) => {
    event.stopPropagation();
    dropdownMenu.classList.toggle('hidden');
});

// Menyembunyikan dropdown menu jika klik di luar menu
window.addEventListener('click', (event) => {
    if (!accountToggle.contains(event.target) && !dropdownMenu.contains(event.target)) {
        dropdownMenu.classList.add('hidden');
    }
});

// Menutup overlay dan dropdown notifikasi saat overlay diklik
overlay.addEventListener('click', () => {
    notificationDropdown.classList.add('hidden');
    overlay.classList.add('hidden');
});

// Mengambil data pengguna dari API
const fetchUserData = async () => {
    const username = localStorage.getItem('username') || 'null';
    const password = 'DEBIAN123'; // Password yang sama dengan yang ada di PHP
    try {
        const response = await fetch('https://api-traives.my.id/api/get-data.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: new URLSearchParams({
                password: password,
                username: username // Kirim username untuk mendapatkan data spesifik
            }),
        });

        if (!response.ok) {
            throw new Error('Network response was not ok ' + response.statusText);
        }

        const user = await response.json(); // Ambil data pengguna
        if (user) {
            // Header data update 
            document.getElementById('username').innerText = user.username;
            document.getElementById('email').innerText = user.email;
            accountToggle.innerText = user.email; 

            // Sidebar profil menu data update 
            document.getElementById('profileName').textContent = user.username;
            document.getElementById('profileEmail').textContent = user.email;
            document.getElementById('regdate').textContent = "Registration date : " + user.registrationdate;
            document.getElementById('sideloc').textContent = "Version App : " + user.version;

            // Ambil data semua pengguna
            await fetchAllMembers(); // Panggil fungsi untuk mengambil semua anggota
        } else {
            console.error('User  tidak ditemukan');
        }
    } catch (error) {
        console.error('Error fetching user data:', error);
    }
};

// Fungsi untuk mengambil semua anggota
const fetchAllMembers = async () => {
    try {
        const response = await fetch('https://api-traives.my.id/api/get-member.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: new URLSearchParams({
                //action: 'get_all_users' // Menambahkan action untuk mendapatkan semua pengguna
            }),
        });

        if (!response.ok) {
            throw new Error('Network response was not ok ' + response.statusText);
        }

        const members = await response.json(); // Ambil data semua anggota
        displayAllMembers(members); // Tampilkan semua anggota
    } catch (error) {
        console.error('Error fetching all members:', error);
    }
};

// Fungsi untuk menampilkan semua anggota di sidebar
const displayAllMembers = (members) => {
    const memberList = document.getElementById('memberList');
    memberList.innerHTML = ''; // Kosongkan daftar sebelum menambahkan

    const onlineMembers = document.createElement('div');
    const offlineMembers = document.createElement('div');
    const separator = document.createElement('div');

    // Tambahkan gaya untuk garis kuning
    separator.style.borderTop = '2px solid #FF9F00';
    separator.style.margin = '10px 0';

    // Tambahkan header untuk anggota online
    const onlineHeader = document.createElement('h3');
    onlineHeader.textContent = 'Online Members';
    onlineMembers.appendChild(onlineHeader);

    // Tambahkan header untuk anggota offline
    const offlineHeader = document.createElement('h3');
    offlineHeader.textContent = 'Offline Members';
    offlineMembers.appendChild(offlineHeader);

    members.forEach(member => {
        const memberDiv = document.createElement('div');
        memberDiv.className = 'member';

        // Tentukan teks dan warna berdasarkan status
        const statusText = member.status === 'online' ? 'Online' : 'Offline';
        const statusColor = member.status === 'online' ? 'green' : 'red';

        memberDiv.innerHTML = `
            <img src="https://api-traives.my.id/api/${member.photo || 'https://placehold.co/40x40'}" alt="Profile Picture">
            <div class="member-info">
                <p class="member-name">${member.username}</p>
                <p class="member-status" style="color: ${statusColor};">${statusText}</p>
            </div>
        `;

        // Tambahkan event listener untuk menampilkan card informasi anggota
        memberDiv.addEventListener('click', (event) => {
            showMemberCard(member, event);
        });

        // Tambahkan anggota ke div yang sesuai
        if (member.status === 'online') {
            onlineMembers.appendChild(memberDiv);
        } else {
            offlineMembers.appendChild(memberDiv);
        }
    });

    // Tambahkan anggota online dan offline ke memberList
    memberList.appendChild(onlineMembers);
    memberList.appendChild(separator);
    memberList.appendChild(offlineMembers);
};

let currentCard = null; // Variabel untuk menyimpan card yang sedang ditampilkan

const showMemberCard = (member, event) => {
        // Tutup card yang sedang ditampilkan jika ada
        if (currentCard) {
                document.body.removeChild(currentCard);
        }

        const card = document.createElement('div');
        currentCard = card; // Simpan referensi card yang baru dibuat
        card.className = 'profile-card';
        card.style.position = 'fixed';
        card.style.zIndex = '1000';

        // Mengatur posisi card berdasarkan posisi klik
        const cardWidth = 300; // Lebar card
        const cardHeight = 200; // Tinggi card
        const offset = 20; // Offset untuk menghindari card terlalu dekat dengan tepi layar
        const x = event.clientX - cardWidth - offset; // Posisi X dengan offset untuk muncul di sebelah kiri
        const y = event.clientY; // Posisi Y tetap sama

        // Menghindari card keluar dari jendela
        card.style.left = x < 0 ? `${offset}px` : `${x}px`;
        card.style.top = (y + cardHeight > window.innerHeight) ? `${window.innerHeight - cardHeight - offset}px` : `${y}px`;

        // Fetch konten dari card.html
        fetch('card.html')
                .then(response => {
                        if (!response.ok) {
                                throw new Error('Network response was not ok: ' + response.statusText);
                        }
                        return response.text();
                })
                .then(html => {
                        // Ganti placeholder dengan data anggota
                        const populatedHtml = html
                                .replace(/{{photo}}/g, member.photo ? `https://api-traives.my.id/api/${member.photo}` : 'https://placehold.co/80x80')
                                .replace(/{{username}}/g, member.username)
                                .replace(/{{email}}/g, member.email)
                                .replace(/{{joinedDate}}/g, member.joinedDate || 'Unknown')
                                .replace(/{{lastSeen}}/g, member.lastSeen || 'Unknown')
                                .replace(/{{messageCount}}/g, member.messageCount || '0')
                                .replace(/{{reactionScore}}/g, member.reactionScore || '0')
                                .replace(/{{points}}/g, member.points || '0');

                        card.innerHTML = populatedHtml;
                        document.body.appendChild(card);

                        // Tambahkan event listener untuk menutup card saat diklik di luar card
                        const handleClickOutside = (event) => {
                                if (currentCard && !card.contains(event.target)) {
                                        document.body.removeChild(card);
                                        currentCard = null; // Reset referensi card yang ditampilkan
                                        document.removeEventListener('click', handleClickOutside); // Hapus event listener setelah card ditutup
                                }
                        };

                        // Tambahkan event listener pada document
                        document.addEventListener('click', handleClickOutside);

                        // Tambahkan event listener untuk menghentikan bubbling saat mengklik di dalam card
                        card.addEventListener('click', (event) => {
                                event.stopPropagation(); // Mencegah event bubble ke document
                        });
                })
                .catch(error => {
                        console.error('Error loading card HTML:', error);
                });
};


        
// Mengambil data pengguna saat konten halaman dimuat
document.addEventListener('DOMContentLoaded', () => {
        fetchUserData();
        setInterval(fetchAllMembers, 10000); // Memanggil fungsi setiap 10 detik
});
// Menavigasi ke halaman 
const profileLink = document.getElementById('profileLink');
const forumLink = document.getElementById('forumLink');
const homeLink = document.getElementById('homeLink');
const settingsLink = document.getElementById('settingsLink');
const profileDetailLink = document.getElementById('profileDetailLink');

// Navigasi ke halaman profil
profileLink.addEventListener('click', (event) => {
    event.preventDefault(); // Mencegah perilaku default tautan
    onNavigate('profile'); // Panggil fungsi navigasi
    dropdownMenu.classList.add('hidden'); // Sembunyikan dropdown menu
});

// Navigasi ke halaman detail profil
profileDetailLink.addEventListener('click', (event) => {
    event.preventDefault(); // Mencegah perilaku default tautan
    onNavigate('profile'); // Panggil fungsi navigasi
});

// Navigasi ke halaman forum
forumLink.addEventListener('click', (event) => {
    event.preventDefault(); // Mencegah perilaku default tautan
    onNavigate('forum'); // Panggil fungsi navigasi
});

// Navigasi kembali ke halaman utama
homeLink.addEventListener('click', (event) => {
    event.preventDefault(); // Mencegah perilaku default tautan
    onNavigate('home'); // Panggil fungsi navigasi
});

// Menavigasi ke halaman pengaturan saat tautan pengaturan diklik
settingsLink.addEventListener('click', (event) => {
    event.preventDefault(); // Mencegah perilaku default tautan
    onNavigate('settings'); // Panggil fungsi navigasi
});