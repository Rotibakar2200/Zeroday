function App() {
                    const [users, setUsers] = React.useState([]);
                    const [showPassword, setShowPassword] = React.useState(false);
                    const [errorMessage, setErrorMessage] = React.useState('');
                    const [isChecked, setIsChecked] = React.useState(false);
                    const [showNotification, setShowNotification] = React.useState(false);
            
                    React.useEffect(() => {
                            const fetchData = async () => {
                                    try {
                                            const response = await fetch('https://api-traives.my.id/api/login.php', {
                                                    method: 'POST',
                                                    headers: {
                                                            'Content-Type': 'application/x-www-form-urlencoded',
                                                    },
                                                    body: new URLSearchParams({
                                                            username: 'exampleUsername', // Ganti dengan username yang sesuai
                                                            password: 'DEBIAN123', // Ganti dengan password yang sesuai
                                                    }),
                                            });
            
                                            if (!response.ok) {
                                                    throw new Error('Network response was not ok');
                                            }
            
                                            const data = await response.json();
                                            setUsers(data); // Simpan data pengguna ke state
                                    } catch (error) {
                                            console.error('Error fetching users:', error);
                                    }
                            };
            
                            fetchData();
                    }, []);
            
                    const handleLogin = async () => {
                            const username = document.getElementById('email').value;
                            const password = document.getElementById('password').value;
                    
                            if (!isChecked) {
                                    setErrorMessage('Anda harus menyetujui ketentuan untuk melanjutkan.');
                                    return;
                            }
                    
                            try {
                                    const response = await fetch('https://api-traives.my.id/api/login.php', {
                                            method: 'POST',
                                            headers: {
                                                    'Content-Type': 'application/x-www-form-urlencoded',
                                            },
                                            body: new URLSearchParams({
                                                    username: username,
                                                    password: password,
                                            }),
                                    });
                    
                                    const data = await response.json();
                    
                                    if (data.message === "Login berhasil") {
                                            localStorage.setItem('isLoggedIn', 'true'); // Set login flag
                                            localStorage.setItem('username', username); // Store username
                                            window.location.href = 'index.html'; // Redirect to main page
                                    } else {
                                            setErrorMessage(data.message); // Tampilkan pesan kesalahan dari server
                                    }
                            } catch (error) {
                                    console.error('Error during login:', error);
                                    setErrorMessage('Terjadi kesalahan saat melakukan login.');
                            }
                    };
            
                    const handleCheckboxChange = () => {
                            setIsChecked(!isChecked);
                            setShowNotification(!isChecked); // Tampilkan atau sembunyikan notifikasi
                    };
            
                    const closeNotification = () => {
                            setShowNotification(false); // Menutup notifikasi
                    };

            return (
                <div className="login-container w-full max-w-sm mx-auto bg-[#161616] rounded-lg shadow-lg p-12">
                    <div className="text-center mb-8">
                        <img src="image/imaDge.png" alt="Logo" className="mx-auto mb-2 w-34 h-34" />
                        <div className="flex justify-center items-center">
                            <div className="text-white text-4xl font-bold">Zero</div>
                            <div className="relative">
                                <div className="text-white text-4xl font-bold">Day</div>
                                <div className="absolute top-0 right-0 transform translate-x-1/2 -translate-y-1/2">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-8 w-8 text-[#FF9F00]" viewBox="0 0 24 24" fill="currentColor">
                                        <path d="M12 0C5.373 0 0 5.373 0 12s5.373 12 12 12 12-5.373 12-12S18.627 0 12 0zm0 22C6.486 22 2 17.514 2 12S6.486 2 12 2s10 4.486 10 10-4.486 10-10 10z"/>
                                        <path d="M12 6.5c-3.033 0-5.5 2.467-5.5 5.5s2.467 5.5 5.5 5.5 5.5-2.467 5.5-5.5-2.467-5.5-5.5-5.5zm0 9c-1.93 0-3.5-1.57-3.5-3.5S10.07 8.5 12 8.5s3.5 1.57 3.5 3.5-1.57 3.5-3.5 3.5z"/>
                                        <path d="M12 10.5c-.827 0-1.5.673-1.5 1.5s.673 1.5 1.5 1.5 1.5-.673 1.5-1.5-.673-1.5-1.5-1.5z"/>
                                    </svg>
                                </div>
                            </div>
                        </div>
                        <p className="text-gray-400 text-base">We're excited to see you again!</p>
                    </div>
                    <div className="mb-6">
                        <label className="block text-gray-400 mb-2 text-lg" htmlFor="email">Email or Phone Number</label>
                        <input className="w-full px-4 py-3 mb-4 bg-[#1E1E1E] text-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-[#FF9F00]" type="text" id="email" placeholder="Enter your email or phone" />
                        <label className="block text-gray-400 mb-2 text-lg" htmlFor="email"> Password here</label>
                        <div className="relative">
                            <input 
                                className="w-full px-4 py-3 bg-[#1E1E1E] text-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-[#FF9F00] pr-10" 
                                type={showPassword ? "text" : "password"} 
                                id="password" 
                                placeholder="Password" 
                            />
                            <i 
                                className={`fas ${showPassword ? 'fa-eye-slash' : 'fa-eye'} absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 cursor-pointer`} 
                                onClick={() => setShowPassword(!showPassword)}
                            ></i>
                        </div>
                    </div>
                    {errorMessage && <div className=" text-red-500 mb-4 text-center text-lg">{errorMessage}</div>}
                    <div className="flex justify-between text-sm text-red-500 mb-6">
                        <a href="#" className="mr-4">Forgot your password?</a>
                        <a href="#">Use a password manager?</a>
                    </div>
 {showNotification && (
                        <div className="notification mb-4">
                            <div className="flex justify-between items-center">
                                <span>🔒 <strong>Penting!</strong> Aplikasi ini dirancang untuk pemantauan dan pengawasan yang sah. Pastikan untuk mematuhi semua hukum dan peraturan yang berlaku di wilayah Anda.</span>
                                <button onClick={closeNotification} className="text-gray-400 hover:text-gray-200">
                                    <i className="fas fa-times"></i>
                                </button>
                            </div>
                            <div className="notification-content overflow-y-auto max-h-64"> {/* Add a wrapper with overflow-y-auto and max height */}
                                <p>Berikut adalah beberapa ketentuan yang perlu diperhatikan:</p>
                                <ol className="list-decimal list-inside">
                                    <li>
                                        <strong>Penggunaan yang Sah:</strong> Gunakan aplikasi ini hanya untuk tujuan yang etis dan legal. Dilarang keras untuk kegiatan ilegal seperti penyadapan tanpa izin atau pelanggaran privasi.
                                    </li>
                                    <li>
                                        <strong>Persetujuan:</strong> Pastikan Anda mendapatkan izin dari individu yang akan dipantau sebelum menggunakan aplikasi ini. Tanpa persetujuan, Anda berisiko menghadapi konsekuensi hukum.
                                    </li>
                                    <li>
                                        <strong>Tanggung Jawab:</strong> Pengembang tidak bertanggung jawab atas penyalahgunaan aplikasi. Anda bertanggung jawab penuh atas semua tindakan yang diambil.
                                    </li>
                                    <li>
                                        <strong>Konsekuensi Hukum:</strong> Penggunaan aplikasi ini untuk tujuan ilegal dapat dikenakan sanksi hukum. Pahami dan patuhi semua hukum yang berlaku di wilayah Anda.
                                    </li>
                                    <li>
                                        <strong>Pembaruan dan Perubahan:</strong> Pengembang berhak untuk memperbarui syarat dan ketentuan kapan saja. Pastikan untuk memeriksa secara berkala.
                                    </li>
                                </ol>
                                <p>Dengan menggunakan aplikasi ini, Anda menyatakan bahwa telah membaca, memahami, dan setuju untuk terikat oleh syarat dan ketentuan di atas.</p>
                            </div>
                        </div>
                    )}
                    <div className="flex justify-center mb-4">
                        <input 
                            type="checkbox" 
                            id="terms" className="mr-2" 
                            onChange={handleCheckboxChange} 
                        />
                        <label className="text-gray-400 text-sm" htmlFor="terms">
                            Saya telah membaca, memahami, dan setuju untuk terikat oleh syarat dan ketentuan di atas.
                        </label>
                    </div>
                    <div className="flex justify-center">
                        <button 
                            className={`w-full py-3 bg-[#FF9F00] rounded text-black font-bold text-lg hover:bg-[#FF9F00] transition duration-200 ${isChecked ? '' : 'cursor-not-allowed opacity-50'}`} 
                            onClick={handleLogin} 
                            disabled={!isChecked}
                        >
                            Log In
                        </button>
                    </div>
                    <div className="text-center text-gray-400 mt-6">
                      <p className="text-lg ">You don't have an account? <a href="register.html" className="text-[#FF9F00] hover:underline ">Register </a></p>
                    </div>
                </div>
            );
        }

        ReactDOM.render(<App />, document.getElementById('root'));