let userActive = true; // Variabel untuk melacak aktivitas pengguna

// Fungsi untuk memperbarui status pengguna
async function updateUserStatus(username, status) {
        try {
                const response = await fetch('https://api-traives.my.id/api/update-status.php', {
                        method: 'POST',
                        headers: {
                                'Content-Type': 'application/x-www-form-urlencoded',
                        },
                        body: new URLSearchParams({
                                username: username,
                                status: status,
                        }),
                });

                const data = await response.json();
               console.log(data.message); // Log pesan dari server
        } catch (error) {
                console.error('Error updating user status:', error);
        }
}

// Memperbarui status pengguna menjadi online saat halaman dimuat
window.addEventListener('load', () => {
        const username = localStorage.getItem('username');
        if (username) {
                // Set status menjadi online
                updateUserStatus(username, 'online');

                // Set interval untuk memperbarui status setiap 10 detik
                setInterval(() => {
                        if (userActive) {
                                updateUserStatus(username, 'online');
                        }
                }, 30000); // Memperbarui setiap 10 detik

        }
});

