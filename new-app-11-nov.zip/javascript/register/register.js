function App() {
    const [errorMessage, setErrorMessage] = React.useState('');
    const [isChecked, setIsChecked] = React.useState(false);
    const [showNotification, setShowNotification] = React.useState(false);
    const [message, setMessage] = React.useState('');

    const handleRegister = () => {
    const username = document.getElementById('username').value;
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const licenseKey = document.getElementById('licenseKey').value;
    const profilePhoto = document.getElementById('profilePhoto').files[0];

    if (!username || !email || !password || !licenseKey || !profilePhoto) {
        setErrorMessage('Semua kolom harus diisi termasuk foto.');
        return;
    }

    if (isChecked) {
        const formData = new FormData();
        formData.append('username', username);
        formData.append('email', email);
        formData.append('password', password);
        formData.append('licensekey', licenseKey);

        // Mengacak nama file foto profil
        const randomFileName = `profile_${Math.random().toString(36).substring(2, 15)}_${profilePhoto.name}`;
        formData.append('photo', new File([profilePhoto], randomFileName, { type: profilePhoto.type }));

        formData.append('phone', "Not add");
        formData.append('iprdp', "On Progress....");
        formData.append('userrdp', "On Progress....");
        formData.append('passrdp', "On Progress....");
        formData.append('expireddate', "On Progress....");

        // Mengisi tanggal pendaftaran otomatis
        const currentDate = new Date().toISOString().split('T')[0]; // Format YYYY-MM-DD
        formData.append('registrationdate', currentDate);
        
        formData.append('userkey', "On Progress....");
        formData.append('version', "ZeroDay v1.0");
        formData.append('downloadlink', "https://example.com/download/ali");

        fetch('https://api-traives.my.id/api/register.html', {
            method: 'POST',
            body: formData,
        })
        .then(response => response.text())
        .then(data => {
            setMessage(data);
        })
        .catch(error => {
            console.error('Error:', error);
            setMessage('Terjadi kesalahan. Silakan coba lagi.');
        });
    } else {
        setErrorMessage('Anda harus menyetujui ketentuan untuk melanjutkan.');
    }
};
    const handleCheckboxChange = () => {
        setIsChecked(!isChecked);
        setShowNotification(!isChecked); // Tampilkan atau sembunyikan notifikasi
    };

    const closeNotification = () => {
        setShowNotification(false); // Menutup notifikasi
    };

    return (
        <div className="registration-container w-full max-w-sm mx-auto bg-[#161616] rounded-lg shadow-lg">
            <div className="text-center mb-4">
                <img src="image/imaDge.png" alt="Logo" className="mx-auto mb-2 w-32 h-32" />
                <div className="flex justify-center items-center">
                    <div className="text-white text-4xl font-bold">Zero</div>
                    <div className="relative">
                        <div className="text-white text-4xl font-bold">Day</div>
                        <div className="absolute top-0 right-0 transform translate-x-1/2 -translate-y-1/2">
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-[#FF9F00]" viewBox="0 0 24 24" fill="currentColor">
                                <path d="M12 0C5.373 0 0 5.373 0 12s5.373 12 12 12 12-5.373 12-12S18.627 0 12 0zm0 22C6.486 22 2 17.514 2 12S6.486 2 12 2s10 4.486 10 10-4.486 10-10 10z"/>
                                <path d="M12 6.5c-3.033 0-5.5 2.467-5.5 5.5s2.467 5.5 5.5 5.5 5.5-2.467 5.5-5.5-2.467-5.5-5.5-5.5zm0 9c-1.93 0-3.5-1.57-3.5-3.5S10.07 8.5 12 8.5s3.5 1.57 3.5 3.5-1.57 3.5-3.5 3.5z"/>
                                <path d="M12 10.5c-.827 0-1.5.673-1 .5 1.5s.673 1.5 1.5 1.5-1.5-.673-1.5-1.5-1.5z"/>
                            </svg>
                        </div>
                    </div>
                </div>
                <p className="text-gray-400 text-sm">Create your account!</p>
                {errorMessage && <p className="text-red-500 text-sm">{errorMessage}</p>}
            </div>
            <div className="mb-4">
                <label className="block text-gray-400 mb-1 text-lg" htmlFor="username">Username</label>
                <input className="w-full px-4 py-3 mb-2 bg-[#1E1E1E] text-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-[#FF9F00]" type="text" id="username" placeholder="Enter your username" />
            </div>
            <div className="mb-4">
                <label className="block text-gray-400 mb-1 text-lg" htmlFor="email">Email</label>
                <input className="w-full px-4 py-3 mb-2 bg-[#1E1E1E] text-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-[#FF9F00]" type="email" id="email" placeholder="Enter your email" />
            </div>
            <div className="mb-4">
                <label className="block text-gray-400 mb-1 text-lg" htmlFor="password">Password</label>
                <input 
                    className="w-full px-4 py-3 mb-2 bg-[#1E1E1E] text-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-[#FF9F00] pr-10" 
                    type="password" 
                    id="password" 
                    placeholder="Enter your password" 
                />
            </div>
            <div className="mb-4">
                <label className="block text-gray-400 mb-1 text-lg" htmlFor="licenseKey">License Key</label>
                <input className="w-full px-4 py-3 mb-2 bg-[#1E1E1E] text-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-[#FF9F00]" type="text" id="licenseKey" placeholder="Enter your license key" />
            </div>
            <div className="mb-4">
                <label className="block text-gray-400 mb-1 text-lg" htmlFor="profilePhoto">Foto Profil</label>
                <input type="file" id="profilePhoto" accept="image/*" className="w-full px-4 py-3 mb-2 bg-[#1E1E1E] text-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-[#FF9F00]" />
            </div>

            {showNotification && (
                <div className="notification mb-4">
                    <div className="flex justify-between items-center">
                        <span>ðŸ”’ <strong>Penting!</strong> Aplikasi ini dirancang untuk pemantauan dan pengawasan yang sah. Pastikan untuk mematuhi semua hukum dan peraturan yang berlaku di wilayah Anda.</span>
                        <button onClick={closeNotification} className="text-gray-400 hover:text-gray-200">
                            <i className="fas fa-times"></i>
                        </button>
                    </div>
                    <div className="notification-content overflow-y-auto max-h-64">
                        <p>Berikut adalah beberapa ketentuan yang perlu diperhatikan:</p>
                        <ol className="list-decimal list-inside">
                            <li>
                                <strong>Penggunaan yang Sah:</strong> Gunakan aplikasi ini hanya untuk tujuan yang etis dan legal. Dilarang keras untuk kegiatan ilegal seperti penyadapan tanpa izin atau pelanggaran privasi.
                            </li>
                            <li>
                                <strong>Persetujuan:</strong> Pastikan Anda mendapatkan izin dari individu yang akan dipantau sebelum menggunakan aplikasi ini. Tanpa persetujuan, Anda berisiko menghadapi konsekuensi hukum.
                            </li>
                            <li>
                                <strong>Tanggung Jawab:</strong> Pengembang tidak bertanggung jawab atas penyalahgunaan aplikasi. Anda bertanggung jawab penuh atas semua tindakan yang diambil.
                            </li>
                            <li>
                                <strong>Konsekuensi Hukum:</strong> Penggunaan aplikasi ini untuk tujuan ilegal dapat dikenakan sanksi hukum. Pahami dan patuhi semua hukum yang berlaku di wilayah Anda.
 </li>
                            <li>
                                <strong>Pembaruan dan Perubahan:</strong> Pengembang berhak untuk memperbarui syarat dan ketentuan kapan saja. Pastikan untuk memeriksa secara berkala.
                            </li>
                        </ol>
                        <p>Dengan menggunakan aplikasi ini, Anda menyatakan bahwa telah membaca, memahami, dan setuju untuk terikat oleh syarat dan ketentuan di atas.</p>
                    </div>
                </div>
            )}
            <div className ="flex justify-center mb-4">
                <input 
                    type="checkbox" 
                    id="terms" className="mr-2" 
                    onChange={handleCheckboxChange} 
                />
                <label className="text-gray-400 text-sm" htmlFor="terms">
                    Saya telah membaca, memahami, dan setuju untuk terikat oleh syarat dan ketentuan di atas.
                </label>
            </div>
            <div className="flex justify-center">
                <button 
                    className={`w-full py-3 bg-[#FF9F00] rounded text-white font-bold text-sm hover:bg-[#FF9F00] transition duration-200 ${isChecked ? '' : 'cursor-not-allowed opacity-50'}`} 
                    onClick={handleRegister} 
                    disabled={!isChecked}
                >
                    Register
                </button>
            </div>
            <div className="text-center text-gray-400 mt-4">
                <p className="text-sm ">Already have an account? <a href="login.html" className="text-[#FF9F00] hover:underline ">Log In</a></p>
                <p className={`text-sm ${message.includes('kesalahan') ? 'text-red-500' : ''}`}>{message}</p>
            </div>
        </div>
    );
}

ReactDOM.render(<App />, document.getElementById('root'));