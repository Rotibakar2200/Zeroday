<?php
// Mengimpor file koneksi
require 'connectionDb.php';

// Cek apakah ada data POST yang dikirim
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Ambil data dari POST
    $username = $_POST['username'] ?? '';
    $email = $_POST['email'] ?? '';
    $photo = $_FILES['photo'] ?? null;
    $banner = $_POST['banner'] ?? '';

    // Update data pengguna
    $stmt = $conn->prepare("UPDATE users SET email = ?, banner = ? WHERE username = ?");
    $stmt->bind_param("sss", $email, $banner, $username);

    // Eksekusi query
    if ($stmt->execute()) {
        // Jika ada foto yang diupload
        if ($photo && $photo['error'] === UPLOAD_ERR_OK) {
            $targetDir = "profilPhoto/"; // Pastikan direktori ini ada dan dapat ditulis
            $targetFile = $targetDir . basename($photo['name']);
            
            // Pindahkan file ke direktori tujuan
            if (move_uploaded_file($photo['tmp_name'], $targetFile)) {
                // Update foto di database
                $stmt = $conn->prepare("UPDATE users SET photo = ? WHERE username = ?");
                $stmt->bind_param("ss", $targetFile, $username);
                $stmt->execute();
            }
        }

        // Mengembalikan respons sukses
        echo json_encode(['success' => true, 'photo' => $targetFile ?? null, 'banner' => $banner]);
    } else {
        // Jika update gagal
        http_response_code(500);
        echo json_encode(['error' => 'Failed to update profile']);
    }
} else {
    // Jika bukan permintaan POST
    http_response_code(405);
    echo json_encode(['error' => 'Method Not Allowed']);
}

// Menutup koneksi
$stmt->close();
$conn->close();
?>