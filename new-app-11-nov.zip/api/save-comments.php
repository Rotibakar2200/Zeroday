<?php
// Mengimpor file koneksi
require 'connectionDb.php';

// Mengambil data dari permintaan
$data = json_decode(file_get_contents('php://input'), true);
error_log(print_r($data, true)); // Log data yang diterima

// Password untuk autentikasi
$password = 'DEBIAN123';
if (!isset($data['password']) || $data['password'] !== $password) {
    http_response_code(403); // Forbidden
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

// Ambil data komentar
$username = $data['username'] ?? 'Anonymous';
$comment = $data['comment'] ?? null;
$replyTo = $data['replyTo'] ?? null;
$like = $data['like'] ?? false;

// Menangani permintaan untuk menyukai komentar
if ($like && isset($data['comment_id'])) {
    $stmt = $conn->prepare("UPDATE comments SET likes = likes + 1 WHERE id = ?");
    $stmt->bind_param("i", $data['comment_id']); // Menggunakan ID komentar untuk menyukai
    if (!$stmt->execute()) {
        echo json_encode(['success' => false, 'message' => 'Database error: ' . $stmt->error]);
        exit;
    }
    echo json_encode(['success' => true, 'message' => 'Comment liked successfully']);
    $stmt->close();
    exit;
}

// Validasi input untuk komentar dan balasan
if ($comment === null || trim($comment) === '') {
    echo json_encode(['success' => false, 'message' => 'Comment cannot be empty']);
    exit;
}

// Menambahkan komentar baru
if ($comment && !$replyTo) {
    $userPhoto = $data['userPhoto'] ?? null; // Ambil foto profil dari data
    $stmt = $conn->prepare("INSERT INTO comments (author, text, photo) VALUES (?, ?, ?)"); // Tambahkan kolom foto
    $stmt->bind_param("sss", $username, $comment, $userPhoto); // Sertakan foto dalam binding
    if (!$stmt->execute()) {
        echo json_encode(['success' => false, 'message' => 'Database error: ' . $stmt->error]);
        exit;
    }
    echo json_encode(['success' => true, 'message' => 'Comment added successfully']);
    $stmt->close();
    exit;
}

// Menambahkan balasan
if ($comment && $replyTo) {
    $stmt = $conn->prepare("INSERT INTO replies (comment_id, author, text) VALUES (?, ?, ?)");
    $stmt->bind_param("iss", $replyTo, $username, $comment);
    if (!$stmt->execute()) {
        echo json_encode(['success' => false, 'message' => 'Database error: ' . $stmt->error]);
        exit;
    }
    echo json_encode(['success' => true, 'message' => 'Reply added successfully']);
    $stmt->close();
    exit;
}

// Mengambil komentar dari database
$result = $conn->query("SELECT * FROM comments");
$comments = [];
while ($row = $result->fetch_assoc()) {
    $row['replies'] = [];
    $comments[$row['id']] = $row; // Simpan berdasarkan ID
}

// Mengambil balasan
$result = $conn->query("SELECT * FROM replies");
while ($row = $result->fetch_assoc()) {
    $comments[$row['comment_id']]['replies'][] = $row;
}

// Mengembalikan respons sukses dan data komentar
echo json_encode(['success' => true, 'comments ```php
' => array_values($comments)]);

$conn->close();
?>