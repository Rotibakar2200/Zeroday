<?php
// Mengimpor file koneksi
require 'connectionDb.php';


$username = $_POST['username'] ?? null;
$status = $_POST['status'] ?? null;

if ($username && $status) {
    if ($status === 'online') {
        // Update status menjadi online
        $updateStmt = $conn->prepare("UPDATE users SET status = 'online', last_active = NOW() WHERE username = ?");
        $updateStmt->bind_param("s", $username);
        $updateStmt->execute();
        $updateStmt->close();
        
        echo json_encode(["message" => "Status berhasil diperbarui menjadi online"]);
    } else {
        // Cek waktu terakhir aktif
        $result = $conn->query("SELECT last_active FROM users WHERE username = '$username'");
        $row = $result->fetch_assoc();
        
        if ($row) {
            $lastActive = strtotime($row['last_active']);
            $currentTime = time();
            
            // Jika sudah lebih dari 10 detik, set status menjadi offline
            if (($currentTime - $lastActive) > 10) {
                $updateStmt = $conn->prepare("UPDATE users SET status = 'offline' WHERE username = ?");
                $updateStmt->bind_param("s", $username);
                $updateStmt->execute();
                $updateStmt->close();
                
                echo json_encode(["message" => "Status berhasil diperbarui menjadi offline"]);
            } else {
                echo json_encode(["message" => "Status masih online"]);
            }
        } else {
            echo json_encode(["message" => "Pengguna tidak ditemukan."]);
        }
    }
} else {
    echo json_encode(["message" => "Data tidak valid."]);
}

$conn->close();
?>