<?php
// Mengimpor file koneksi
require 'connectionDb.php';

// Mengambil komentar dari database
$result = $conn->query("SELECT * FROM comments");
$comments = [];
while ($row = $result->fetch_assoc()) {
    $row['replies'] = []; // Inisialisasi balasan
    $comments[$row['id']] = $row; // Simpan berdasarkan ID
}

// Mengambil balasan
$result = $conn->query("SELECT * FROM replies");
while ($row = $result->fetch_assoc()) {
    $comments[$row['comment_id']]['replies'][] = $row; // Tambahkan balasan ke komentar yang sesuai
}

// Mengembalikan respons sukses dan data komentar
echo json_encode(['success' => true, 'comments' => array_values($comments)]);

$conn->close();
?>