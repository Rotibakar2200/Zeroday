<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");

$host = "localhost";
$usernameDb = "apiw3844_Anjai";
$passwordDb = "root99..00";
$database = "apiw3844_Anjai";

try {
    $pdo = new PDO("mysql:host=$host;dbname=$database;charset=utf8", $usernameDb, $passwordDb);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Database connection failed: ' . $e->getMessage()]);
    exit();
}

$title = $_POST['title'] ?? '';
$content = $_POST['content'] ?? '';
$user = $_POST['user'] ?? '';
$profileImage = $_POST['profileImage'] ?? '';
$image = $_FILES['image'] ?? null;

if (empty($title) || empty($content) || empty($user)) {
    echo json_encode(['success' => false, 'message' => 'All fields are required.']);
    exit();
}

$imagePath = null;
if ($image && $image['error'] === UPLOAD_ERR_OK) {
    $uploadDir = 'uploadPost/';
    $imagePath = $uploadDir . basename($image['name']);
    move_uploaded_file($image['tmp_name'], $imagePath);
}

try {
    $stmt = $pdo->prepare("INSERT INTO posts (title, content, user, profileImage, image) VALUES (?, ?, ?, ?, ?)");
    $stmt->execute([$title, $content, $user, $profileImage, $imagePath]);

    echo json_encode(['success' => true, 'message' => 'Post created successfully.']);
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Error saving post: ' . $e->getMessage()]);
}
?>