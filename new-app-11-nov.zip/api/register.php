<?php
// Mengimpor file koneksi
require 'connectionDb.php';

// Ambil data POST mentah
$username = $_POST['username'] ?? null;
$email = $_POST['email'] ?? null;
$password = $_POST['password'] ?? null;
$licensekey = $_POST['licensekey'] ?? null;
$phone = $_POST['phone'] ?? null;
$iprdp = $_POST['iprdp'] ?? null;
$userrdp = $_POST['userrdp'] ?? null;
$passrdp = $_POST['passrdp'] ?? null;
$expireddate = $_POST['expireddate'] ?? null;
$registrationdate = $_POST['registrationdate'] ?? null; // Tanggal pendaftaran
$userkey = $_POST['userkey'] ?? null;
$version = $_POST['version'] ?? null;
$downloadlink = $_POST['downloadlink'] ?? null;
$photo = $_FILES['photo'] ?? null; // Ambil foto dari file

// Debugging: Log data yang diterima
//error_log("Data yang diterima: " . print_r($_POST, true));

// Cek apakah data valid
if ($username && $email && $password && $licensekey && $photo && $photo['error'] == 0) {
        
    // Cek apakah license key sudah ada
    $stmt = $conn->prepare("SELECT * FROM users WHERE licensekey = ?");
    $stmt->bind_param("s", $licensekey);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        echo 'License key sudah terpakai.';
        exit; // Hentikan eksekusi jika license key sudah ada
    }

    // Hash password
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    // Validasi dan simpan foto
    $targetDir = "profilPhoto/"; // Folder untuk menyimpan foto
    $targetFile = $targetDir . basename($photo["name"]); // Gunakan nama file yang diacak dari frontend
    $imageFileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));

    // Cek apakah file adalah gambar
    $check = getimagesize($photo["tmp_name"]);
    if($check === false) {
        echo "File bukan gambar.";
        exit;
    }

    // Cek ukuran file (misalnya maksimum 2MB)
    if ($photo["size"] > 2000000) {
        echo "Maaf, ukuran file terlalu besar.";
        exit;
    }

    // Cek format file
    $allowedTypes = ['jpg', 'png', 'jpeg', 'gif'];
    if (!in_array($imageFileType, $allowedTypes)) {
        echo "Hanya file JPG, JPEG, PNG & GIF yang diizinkan.";
        exit;
    }

    // Pindahkan file ke folder tujuan
    if (!move_uploaded_file($photo["tmp_name"], $targetFile)) {
        echo "Maaf, terjadi kesalahan saat mengunggah foto.";
        exit;
    }

    // Menambahkan data baru ke database
    $stmt = $conn->prepare("INSERT INTO users (username, email, password, licensekey, phone, iprdp, userrdp, passrdp, expireddate, registrationdate, userkey, version, downloadlink, photo) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssssssssssss", $username, $email, $hashedPassword, $licensekey, $phone, $iprdp, $userrdp, $passrdp, $expireddate, $registrationdate, $userkey, $version, $downloadlink, $targetFile);

    if ($stmt->execute()) {
        echo 'Pendaftaran berhasil.';
    } else {
        echo 'Gagal menyimpan data.';
    }

    // Menutup koneksi
    $stmt->close();
    $conn->close();
} else {
    echo 'Data tidak valid.';
}
?>