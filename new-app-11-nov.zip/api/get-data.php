<?php
// Mengimpor file koneksi
require 'connectionDb.php';

// Cek apakah ada data POST yang dikirim
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Ambil password dan username dari data POST
    $password = $_POST['password'] ?? '';
    $username = $_POST['username'] ?? ''; // Ambil username dari POST

    // Verifikasi password
    if ($password === 'DEBIAN123') { // Ganti dengan password yang sesuai
        // Ambil data pengguna berdasarkan username
        $stmt = $conn->prepare("SELECT username, email, phone, iprdp, userrdp, passrdp, expireddate, registrationdate, userkey, version, downloadlink, photo, banner FROM users WHERE username = ?");
        $stmt->bind_param("s", $username); // Bind parameter untuk mencegah SQL Injection
        $stmt->execute();
        $result = $stmt->get_result();

        // Cek apakah pengguna ditemukan
        if ($result->num_rows > 0) {
            $user = $result->fetch_assoc();
            // Mengembalikan data pengguna dalam format JSON
            echo json_encode($user);
        } else {
            // Jika pengguna tidak ditemukan
            http_response_code(404);
            echo json_encode(['error' => 'User  not found']);
        }
    } else {
        // Jika password salah
        http_response_code(403);
        echo json_encode(['error' => 'Unauthorized']);
    }
} else {
    // Jika bukan permintaan POST
    http_response_code(405);
    echo json_encode(['error' => 'Method Not Allowed']);
}

// Menutup koneksi
$stmt->close();
$conn->close();
?>