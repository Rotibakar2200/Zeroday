<?php
// Mengimpor file koneksi
require 'connectionDb.php';

// Mengambil anggota online
$sql = "SELECT username, email, status, photo FROM users WHERE status = 'online'";
$result = $conn->query($sql);

$members = array();

if ($result->num_rows > 0) {
    // Mengambil data setiap anggota
    while ($row = $result->fetch_assoc()) {
        $members[] = $row;
    }
}

// Mengembalikan data dalam format JSON
header('Content-Type: application/json');
echo json_encode($members);

// Menutup koneksi
$conn->close();
?>