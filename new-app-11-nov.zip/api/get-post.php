<?php
// Mengimpor file koneksi
require 'connectionDb.php';

// Ambil data dari tabel posts
$sql = "SELECT * FROM posts";
$result = $conn->query($sql);

$posts = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        // Pastikan untuk menyertakan kolom gambar dan foto profil
        $posts[] = [
            'id' => $row['id'],
            'title' => $row['title'],
            'content' => $row['content'],
            'user' => $row['user'],
            'image' => $row['image'], // Tambahkan kolom image
            'profileImage' => $row['profileImage'], // Tambahkan kolom profileImage
            'created_at' => $row['created_at']
        ];
    }
}

// Kembalikan data dalam format JSON
echo json_encode($posts);

// Tutup koneksi
$conn->close();
?>