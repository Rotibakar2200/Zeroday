<?php
$host = "localhost"; // Host MySQL
$dbUsername = "apiw3844_Anjai"; // Username MySQL
$dbPassword = "root99..00"; // Password MySQL
$database = "apiw3844_Anjai"; // Nama Database

$conn = new mysqli($host, $dbUsername, $dbPassword, $database);

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Waktu batas untuk dianggap offline (misalnya 30 detik)
$offlineThreshold = 30;

$currentTime = time();
$thresholdTime = $currentTime - $offlineThreshold;

// Update status menjadi offline untuk pengguna yang tidak aktif
$updateStmt = $conn->prepare("UPDATE users SET status = 'offline' WHERE last_active < FROM_UNIXTIME(?)");
$updateStmt->bind_param("i", $thresholdTime);
$updateStmt->execute();

echo "Status pengguna yang tidak aktif telah diperbarui menjadi offline.";

$updateStmt->close();
$conn->close();
?>