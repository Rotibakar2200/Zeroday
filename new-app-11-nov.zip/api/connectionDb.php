<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");

$host = "localhost";
$usernameDb = "apiw3844_Anjai";
$passwordDb = "root99..00";
$database = "apiw3844_Anjai";

try {
    $pdo = new PDO("mysql:host=$host;dbname=$database;charset=utf8", $usernameDb, $passwordDb);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Database connection failed: ' . $e->getMessage()]);
    exit();
}
?>