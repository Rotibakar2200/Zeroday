<?php
// Mengimpor file koneksi
require 'connectionDb.php';

// Ambil data POST
$username = $_POST['username'] ?? null;
$password = $_POST['password'] ?? null;

// Cek apakah data valid
if ($username && $password) {
    // Mencari pengguna dalam database
    $stmt = $conn->prepare("SELECT password FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->store_result();

    // Jika pengguna ditemukan
    if ($stmt->num_rows > 0) {
        $stmt->bind_result($hashedPassword);
        $stmt->fetch();

        // Verifikasi password
        if (password_verify($password, $hashedPassword)) {
            echo json_encode(["message" => "Login berhasil", "username" => $username]);
        } else {
            echo json_encode(["message" => "Password salah"]);
        }
    } else {
        echo json_encode(["message" => "Pengguna tidak ditemukan"]);
    }

    $stmt->close();
} else {
    echo json_encode(["message" => "Data tidak valid."]);
}

// Menutup koneksi
$conn->close();
?>