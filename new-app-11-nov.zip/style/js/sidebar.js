const { useState } = React;

const App = () => {
        const [isSidebarOpen, setIsSidebarOpen] = useState(false);

        const toggleSidebar = () => {
                setIsSidebarOpen(!isSidebarOpen);
        };

        const handleClick = (item) => {
                console.log(`Navigating to ${item}`);
                // Tambahkan logika navigasi sesuai kebutuhan
        };

        return (
                <div className="flex">
            <div className={`fixed top-0 left-0 h-full bg-[#23272A] rounded-r-lg shadow-lg transition-transform duration-300 ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'} w-64`}>
                <div className="flex items-center justify-between p-4">
                    <img src="https://placehold.co/40x40" alt="Logo" className="rounded-full" />
                    <h1 className="text-white text-lg ml-2">MyApp</h1>
                </div>
                <div className="py-4">
                    {['forum', 'remote', 'home', 'docs'].map((item) => (
                        <div
                            key={item}
                            className={`flex items-center cursor-pointer p-4 transition-colors duration-200 hover:bg-[#5865F2] rounded-lg`}
                            onClick={() => handleClick(item)}
                        >
                            <i className={`fas fa-${item === 'forum' ? 'skull' : item === 'remote' ? 'desktop' : item === 'home' ? 'home' : 'book'} text-lg text-white mr-3`}></i>
                            <span className="text-white text-lg">{item.charAt(0).toUpperCase() + item.slice(1)}</span>
                        </div>
                    ))}
                </div>
            </div>

            <div className="flex-grow p-4">
                <button onClick={toggleSidebar} className="bg-blue-600 text-white px-4 py-2 rounded-md">Toggle Sidebar</button>
                <div className="mt-4">
                    {/* Konten utama di sini */}
                </div>
            </div>
        </div>
        );
};

ReactDOM.render(<App />, document.getElementById('root'));