cronjob script update offline member
Current Cron Jobs
*/1
*
*
*
*
/usr/local/bin/ea-php74 /home/apiw3844/public_html/https://api-traives.my.id/api/cronjob/setOffline_cronjob.php